/* eslint-disable no-console */
import fs from 'node:fs/promises';
import neat from 'neat-csv';

/**
 * Reads charts.csv file to obtain billboard data
 * @async
 * @return {Promise<Array<Object>>} A promise that resolves to 
 * an array of unfiltered billboard data.
 */
async function getBaseBillBoardData(){
  try{
    //the route is for running the file from root node server/utils/seed.js
    const response = await fs.readFile('server/data/charts.csv');
    
    const data = await neat(response);

    return data;
  }catch(Error){
    console.log(Error);
  }
}

/**
 * Filters the billboard data based on a specified date range.
 * @async
 * @returns {Promise<Array<Object>>} A promise that resolves to an array 
 * of filtered billboard data.
 */
async function getFilteredBillBoardData(){
  try{
    const songs = await getBaseBillBoardData();
    const startDate = new Date('2010-01-01').toJSON().slice(0, 10);
    const endDate = new Date('2021-12-31').toJSON().slice(0, 10);
    return songs.filter(song => song.date >= startDate && song.date <= endDate);
  }catch (Error){
    console.log(Error);
  }
}

/**
 * Maps billboard data to format with only the fields needed for the program
 * Additionally removes songs that weren't in the spotify database
 * @async
 * @param {spotifyData} spotifyData - Mapped spotify data
 * @returns {Promise<Array<Object>>} A promise that resolves to an array of mapped 
 * and filtered billboard data.
 */
async function getMappedBillBoardData(spotifyData){
  try{
    const songs = await getFilteredBillBoardData();

    const deriveNewFields = (song) => {
      song.title = song.song;
      song.year = parseInt(song.date.slice(0, 4));
      return song;
    };

    const addTimeOnBoard = (song) => {
      song.weeksOnBoard = songs.filter((s) => {
        return s.artist === song.artist 
          && s.title === song.title 
          && s.year === song.year;
      }).length;

      return song;
    };

    const removeFeaturedArtist = (song) => {
      if (song.artist.indexOf(' Featuring') !== -1){
        song.artist = song.artist.substring(0, song.artist.indexOf(' Featuring'));
      }
      return song;
    };

    const removeUnneededFields = (song) => {
      delete song.song;
      delete song.date;
      delete song.rank;
      delete song['last-week'];
      delete song['peak-rank'];
      delete song['weeks-on-board'];
      return song;
    };

    //This is done here so as to reduce the time it takes to derive weeks on billboard property
    const removeSongsNotOnSpotify = (song) => {
      if ( spotifyData.find(spotifySong => {
        if (spotifySong.artist && spotifySong.title){
          return spotifySong.artist.toLowerCase() === song.artist.toLowerCase()
            && spotifySong.title.toLowerCase() === song.title.toLowerCase();
        }
      })){
        return true;
      }
    };

    const removeDuplicates = (song, index, array) => {
      return array.findIndex(s =>
        s.artist === song.artist &&
          s.title === song.title &&
          s.year === song.year
      ) === index;
    };

    return songs.
      map(deriveNewFields).
      map(removeFeaturedArtist).
      map(removeUnneededFields).
      filter(removeSongsNotOnSpotify).
      map(addTimeOnBoard).
      filter(removeDuplicates);
  }catch (Error){
    console.log(Error);
  }
}

/**
 * Reads spotify_full_list.csv file to obtain spotify streaming data
 * @async
 * @return  {Promise<Array<Object>>}array of the unfiltered Spotify data
 */
async function getBaseSpotifyData() {
  try{
    const response = await fs.readFile('server/data/spotify_full_list.csv');

    const data = await neat(response);

    return data;
  }catch(Error){
    console.log(Error);
  }
}

/**
 * Filters Spotify data based on a specified date range and ensures genre information is present.
 * @async
 * @return {Promise<Array<Object>>} A promise that resolves
 *  to an array spotify songs that falls in the required date
 */
async function getFilteredSpotifyData(){
  try{
    const songs = await getBaseSpotifyData();
    const startDate = new Date('2010-01-01').getFullYear() + 1;
    const endDate = new Date('2021-12-31').getFullYear();

    return songs.filter(song => song.year >= startDate && song.year <= endDate).
      filter(song => song.main_genre !== '');
  }catch(Error){
    console.log(Error);
  }
}

/**
 * Maps and processes Spotify data to include only fields required for the program.
 * @async
 * @return {Promise<Array<Object>>} A promise that resolves to an array of mapped spotify data
 */
async function getMappedSpotifyData(){
  try{
    const songs = await getFilteredSpotifyData();

    const deriveNewFields = (song) => {
      //.title provides the title of the song without the artist
      const offset = 3;
      song.title = song['Artist and Title'].
        slice(song.Artist.length + offset, song['Artist and Title'].length);

      //.genre renames the .main_genre field
      song.genre = song.main_genre;
      return song;
    };

    const removeUnneededFields = (song) => {
      delete song.genres;
      delete song.main_genre;
      delete song.first_genre;
      delete song.second_genre;
      delete song.third_genre;
      delete song.Daily;
      delete song.id;
      delete song['Artist and Title'];
      return song;
    };

    const makeFieldsLowerCase = (song) => {
      song.artist = song.Artist;
      song.streams = song.Streams;
      delete song.Artist;
      delete song.Streams;
      return song;
    };

    const roundYearField = (song) => {
      song.year = parseInt(song.year);
      return song;
    };

    return songs.
      map(deriveNewFields).
      map(removeUnneededFields).
      map(makeFieldsLowerCase).
      map(roundYearField);

  }catch(Error){
    console.log(Error);
  }
}

/**
 * Merges spotify and billboard data into one object
 * @param {spotifyData} spotifyData - Mapped spotify data
 * @param {billboardData} billboardData - Mapped billboard data
 * @return array of individual song data with genre, streams, year,
 * weeksOnBoard, title, and artist fields
 */
function consolidateBillboardAndSpotify(spotifyData, billboardData){
  return billboardData.map( billboardSong => {
    const spotifySongData = spotifyData.find(spotifySong => 
      spotifySong.artist.toLowerCase() === billboardSong.artist.toLowerCase()
        && spotifySong.title.toLowerCase() === billboardSong.title.toLowerCase());

    billboardSong.streams = spotifySongData.streams;
    billboardSong.genre = spotifySongData.genre;

    return billboardSong;
  });
}

export {getMappedBillBoardData, getMappedSpotifyData, consolidateBillboardAndSpotify};